"use client";

import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

export function AboutSection() {
  return (
    <section
      id="about"
      className="py-20 bg-black relative overflow-hidden"
    >
      {/* Background gradients */}
      <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-600 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob animation-delay-2000"></div>
      <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-600 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob animation-delay-4000"></div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-purple-400 to-blue-500 bg-clip-text text-transparent mb-6">
              About Void Life
            </h2>
            <div className="space-y-4 text-gray-300">
              <p>
                Void Life is at the forefront of innovative technology designed to keep couples connected regardless of distance. Our groundbreaking platform enables seamless interaction between partners.
              </p>
              <p>
                Founded in Ontario, Canada by three aspiring businessmen — Vedesh, James, and Tyson — Void Life was born from a vision to help couples have more seamless intimate experiences. The trio recognized the challenges of maintaining connection across distances and set out to revolutionize the industry.
              </p>
              <p>
                Our team of passionate engineers and designers work tirelessly to provide you with the most intuitive and enjoyable experience possible, ensuring that physical separation never means emotional distance.
              </p>
              <div className="pt-4">
                <Button
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-medium"
                >
                  Meet the Team
                </Button>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="relative"
          >
            <div className="absolute -inset-1 rounded-lg bg-gradient-to-r from-purple-600 to-blue-600 opacity-30 blur-lg" />
            <div className="relative overflow-hidden rounded-lg bg-black p-8 border border-purple-500/20">
              <h3 className="text-xl font-semibold text-white mb-4">Our Mission</h3>
              <p className="text-gray-400 mb-6">
                "To bridge the gap between physical distance and emotional connection, creating moments of genuine intimacy in a digital world."
              </p>

              <div className="grid grid-cols-2 gap-4 text-center">
                <div className="p-4 rounded-lg bg-black/50 border border-purple-500/30">
                  <div className="text-purple-400 text-3xl font-bold">2025</div>
                  <div className="text-gray-500 text-sm">Launch Year</div>
                </div>
                <div className="p-4 rounded-lg bg-black/50 border border-purple-500/30">
                  <div className="text-purple-400 text-3xl font-bold">Global</div>
                  <div className="text-gray-500 text-sm">Availability</div>
                </div>
                <div className="p-4 rounded-lg bg-black/50 border border-purple-500/30">
                  <div className="text-purple-400 text-3xl font-bold">100+</div>
                  <div className="text-gray-500 text-sm">Vibration & Stroke Patterns</div>
                </div>
                <div className="p-4 rounded-lg bg-black/50 border border-purple-500/30">
                  <div className="text-purple-400 text-3xl font-bold">100%</div>
                  <div className="text-gray-500 text-sm">Secure</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
