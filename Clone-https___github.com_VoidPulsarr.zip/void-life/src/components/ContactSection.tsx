"use client";

import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";

export function ContactSection() {
  return (
    <section
      id="contact"
      className="py-20 bg-gradient-to-b from-gray-900 to-black relative overflow-hidden"
    >
      {/* Background effect */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-black/80" />
        <div
          className="absolute bottom-0 left-0 right-0 h-3/4"
          style={{
            background:
              "linear-gradient(to top, rgba(76, 29, 149, 0.1), transparent)",
          }}
        />
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-purple-400 to-blue-500 bg-clip-text text-transparent mb-4">
              Get in Touch
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Have questions about Void Life? Join our waitlist to get updates on our
              launch and be the first to experience the future of connection.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="bg-black/40 backdrop-blur-sm rounded-lg border border-purple-500/20 p-8"
          >
            <form className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-1">
                    Name
                  </label>
                  <Input
                    id="name"
                    placeholder="Your name"
                    className="bg-black/50 border-purple-500/30 focus:border-purple-500 text-white"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-1">
                    Email
                  </label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your.email@example.com"
                    className="bg-black/50 border-purple-500/30 focus:border-purple-500 text-white"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-1">
                  Message (Optional)
                </label>
                <textarea
                  id="message"
                  rows={4}
                  placeholder="Your message or questions about Void Life"
                  className="w-full rounded-md bg-black/50 border border-purple-500/30 focus:border-purple-500 text-white px-3 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-colors"
                ></textarea>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <input
                    id="newsletter"
                    name="newsletter"
                    type="checkbox"
                    className="h-4 w-4 rounded border-purple-500/30 text-purple-600 focus:ring-purple-500"
                  />
                  <label htmlFor="newsletter" className="ml-2 block text-sm text-gray-400">
                    Join our newsletter
                  </label>
                </div>

                <HoverCard>
                  <HoverCardTrigger>
                    <span className="text-sm text-purple-400 cursor-help">Privacy Policy</span>
                  </HoverCardTrigger>
                  <HoverCardContent className="w-80 bg-black/90 border border-purple-500/30 text-gray-300">
                    <p className="text-sm">
                      We respect your privacy. Your information will never be shared with third parties.
                    </p>
                  </HoverCardContent>
                </HoverCard>
              </div>

              <div>
                <Button
                  className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-medium"
                  size="lg"
                >
                  Join Waitlist
                </Button>
              </div>
            </form>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.4 }}
            className="mt-12 text-center"
          >
            <p className="text-gray-500 text-sm">
              Or reach out directly to{" "}
              <a
                href="https://github.com/VoidPulsarr"
                target="_blank"
                rel="noopener noreferrer"
                className="text-purple-400 hover:text-purple-300 transition-colors"
              >
                Void Pulsar
              </a>{" "}
              or{" "}
              <a
                href="https://github.com/vvedeshh"
                target="_blank"
                rel="noopener noreferrer"
                className="text-purple-400 hover:text-purple-300 transition-colors"
              >
                Vedesh
              </a>
              , our business partners.
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
